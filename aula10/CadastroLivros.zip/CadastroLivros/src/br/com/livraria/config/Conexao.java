package br.com.livraria.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    // Ajuste conforme sua instalação local do MySQL.
    private static final String URL = "jdbc:mysql://localhost:3306/livraria_db";
    private static final String USUARIO = "root";
    private static final String SENHA = "root";
    public Connection abrir() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }
}
